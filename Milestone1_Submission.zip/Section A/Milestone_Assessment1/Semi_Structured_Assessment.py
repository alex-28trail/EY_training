import json
# 7
with open("equipment_events.json", "r") as f:
    event = json.load(f)

for i in event:
    print(
        i["event_id"],
        i["asset"]["type"],
        i["asset"]["site"],
        i["severity"]
    )

#8
for i in event:
    if i.get("temperature", 0) > 70:
        actions = i.get("actions", "No actions recorded")
        print(i["event_id"], i["temperature"], actions)

#