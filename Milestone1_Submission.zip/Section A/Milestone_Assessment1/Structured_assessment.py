import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

df=pd.read_csv('urban_mobility.csv')
print(df.head(5))

df["Energy_Per_kWh"]= df["Energy_Used_kWh"]/df["Distance_Km"]
print(df)

# 3

print(df[(df["Vehicle_Type"]=='Electric Van') & (df["Maintenance_Flag"]=='Yes')])

# 4
print(df.groupby("Vehicle_Type")["Distance_Km"].mean())

# 5
print("Avg_energy",np.average(df["Energy_Used_kWh"]))
print("Highest_energy",np.max(df["Energy_Used_kWh"]))
print("Lowest_energy",np.min(df["Energy_Used_kWh"]))

Avg_Eng= df.groupby("Vehicle_Type")["Energy_Used_kWh"].mean()


# 6
plt.bar(Avg_Eng.index,Avg_Eng.values,align='center')
plt.title("Chart")
plt.xlabel("Avg_Eng")
plt.ylabel("Vehicle_Type")
plt.tight_layout()
plt.show()



