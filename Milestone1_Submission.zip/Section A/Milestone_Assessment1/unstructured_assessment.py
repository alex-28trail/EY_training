# 9
with open("coastal_monitoring_log.txt", "r") as f:
    text = f.read()

words = text.split()

print("total_words:", len(words))
print(
    "inspection_count:",
    text.lower().count("inspection")
)

# 10
keywords = ["boardwalk", "maintenance", "wind"]

with open("coastal_monitoring_log.txt", "r") as f:
    for line in f:
        if any(word in line.lower() for word in keywords):
            print(line.strip())